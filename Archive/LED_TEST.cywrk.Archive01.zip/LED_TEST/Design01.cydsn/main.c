#include "project.h"
#include "stdio.h"
#include "stdlib.h" // Para usar atoi

#define DELAY_MS 100 // Constante para el retardo
#define MAX_PWM_VALUE 255 // Valor máximo para PWM (8 bits)

float32 voltajeADC, temp;
int32 entero, voltaje, pwmValor;
char mensaje[256];
char comando;

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    // Inicializa los componentes
    UART_Start();
    Opamp_Start();
    ADC_Start(); 
    PWM_Start();
    Clock_Start();
    
    for(;;)
    {
        // Lee el valor del ADC
        ADC_StartConvert();
        ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
        entero = ADC_GetResult32();
        ADC_StopConvert();

        // Convierte el valor del ADC a milivoltios
        voltaje = ADC_CountsTo_mVolts(entero);
        
        // Calcula la temperatura (ajusta según tu sensor)
        temp = (voltaje / 10.00); // Suponiendo que 10 mV por grado Celsius
        
        // Recibe un valor de PWM por UART
        UART_PutString("Ingrese un valor de PWM (0-255): ");
        
        // Espera a que el usuario ingrese un valor
        comando = UART_GetChar();
        
        // Convierte el comando a entero
               
        // Asegúrate de que el valor esté dentro del rango válido
        if (pwmValor < 0) {
            pwmValor = 0; // Limita a mínimo
        } else if (pwmValor > MAX_PWM_VALUE) {
            pwmValor = MAX_PWM_VALUE; // Limita a máximo
        }
        
        // Configura el valor del PWM
        PWM_WriteCompare(pwmValor);
        
        // Formatea el mensaje con sprintf
        sprintf(mensaje, "Voltaje: %ld mV, Temp: %.2f °C, PWM: %ld \xF0\x9F\x94\xA5\r\n", voltaje, temp, pwmValor); // Agrega un emoji de fuego
        
        // Envía el mensaje por UART
        UART_PutString(mensaje);
                
        CyDelay(DELAY_MS); // Espera el tiempo definido
    }
}
